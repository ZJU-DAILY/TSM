import torch
import config
from Trainer import T2SV_Trainer
import os
import time

if __name__ == '__main__':
    print('os.environ["CUDA_VISIBLE_DEVICES"]= {}'.format(os.environ["CUDA_VISIBLE_DEVICES"]))
    print(torch.__version__)
    print(torch.cuda.device_count())
    print(torch.cuda.is_available())
    torch.cuda.empty_cache()

    # train and test
    start = time.time()
    T2SV = T2SV_Trainer(target_size=config.d_vector,batch_size=config.batch_size)

    load_model_name = None

    load_optimizer_name = None
    
    T2SV.T2SVtrain(load_model = load_model_name,load_optimizer= load_optimizer_name) # for training
    print(config.dataset, config.distance_type)
    #T2SV.T2SVeval(load_model=load_model_name) #for testing

    end = time.time()
    print("training time:",end -start)
    #print("testing time:",end-start)
