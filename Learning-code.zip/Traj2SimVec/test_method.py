import traj_dist.distance as tdist
import torch
import config
import torch.nn.functional as F
import numpy as np
import pickle
import multiprocessing
import os

def padding(trajs):
    traj_len = []
    maxlen = 0
    for t in trajs:
        traj_len.append(len(t))
        if len(t)>maxlen :
            maxlen = len(t)

    pad_seq = []
    for t in trajs:
        p = [0.0,0.0]
        t = t.tolist()
        while len(t)<maxlen:
            t.append(p)
        pad_seq.append(np.array(t))
    pad_seq = np.array(pad_seq)

    return pad_seq , traj_len

def compute_embedding(self, net, vali, test_size): 
    hidden = (torch.zeros(test_size, config.d_vector).cuda(), torch.zeros(test_size, config.d_vector).cuda())

    if len(vali) == test_size:
        input_vali , input_vali_len = padding(vali)
        input_vali = torch.Tensor(input_vali)
        embedding = net.lstm(input_vali.cuda(),input_vali_len,test_size, hidden)

        # baseline: return embedding

        last_hidden = []
        for t in embedding:
            last_hidden.append(t[-1].data.cpu().numpy())
        last_hidden = torch.Tensor(last_hidden)
        return last_hidden 

    else:
        i = 0
        all_embedding = []
        while i < len(vali):
            input_vali, input_vali_len = padding(vali[i:i + test_size])
            input_vali = torch.Tensor(input_vali)
            embedding = net.lstm(input_vali.cuda(),input_vali_len,test_size, hidden)
            last_hidden = []
            for t in embedding:
                last_hidden.append(t[-1].data.cpu().numpy())
            all_embedding.append(last_hidden)
            i += test_size

        all_embedding = torch.Tensor(all_embedding)
        #combine_emb = torch.cat((all_embedding),0) 
        combine_emb = all_embedding.view(-1,config.d_vector)
        return combine_emb


def test_model(self,input_set, embedding_set, isvali):  
    #dlhu input_dis_matrix = np.load('./features/{}/{}_truth/vali_ground_truth/spatial_truth/{}_{}.npy'.format(config.dataset, config.distance_type, config.dataset, config.distance_type), allow_pickle=True)

    if isvali==True:
        input_dis_matrix = np.load('./features/{}/{}_truth/vali_ground_truth/spatial_truth/{}_{}.npy'.format(config.dataset, config.distance_type, config.dataset, config.distance_type), allow_pickle=True)
    else:
        input_dis_matrix = np.load('./features/{}/{}_truth/test_ground_truth/{}_{}_s.npy'.format(config.dataset, config.distance_type, config.dataset, config.distance_type),allow_pickle=True)
    
    embedding_set = embedding_set.data.cpu().numpy()
    embedding_dis_matrix=[]
    for i, t in enumerate(embedding_set): 
        if i == 6000 and isvali==False: #6000
            break
        emb = np.repeat([t], repeats=len(embedding_set), axis=0)
        matrix = np.linalg.norm(emb - embedding_set, ord=2, axis=1)
        embedding_dis_matrix.append(matrix.tolist())
    
    l_recall_10=0
    l_recall_50=0
    l_recall_10_50 = 0
    
    print("len(input_dis_matrix)",len(input_dis_matrix))
    for i in range(len(input_dis_matrix)):
        input_r = np.array(input_dis_matrix[i])[:6000]
        input_r50 = np.argsort(input_r)[1:51] 
        # input_r50 = input_r[1:51] 
        input_r10 = input_r50[:10]

        embed_r = embedding_dis_matrix[i][:6000]
        embed_r50 = np.argsort(embed_r)[1:51]
        embed_r10 = embed_r50[:10]
        
        l_recall_10+=len(list(set(input_r10).intersection(set(embed_r10)))) 
        l_recall_50+=len(list(set(input_r50).intersection(set(embed_r50))))
        l_recall_10_50 += len(list(set(input_r50).intersection(set(embed_r10))))

    recall_10 = float(l_recall_10) / (10 * len(input_dis_matrix))
    recall_50 = float(l_recall_50) / (50 * len(input_dis_matrix))
    recall_10_50 = float(l_recall_10_50) / (10 * len(input_dis_matrix))

    return recall_10,recall_50,recall_10_50


