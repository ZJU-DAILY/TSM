
GPU = "0"   # ---------

all_traj_number = 10000 # -----------

train_radio=3000  # ------------

k_segment=5
r_subsample=10
r_point_sample=10
margin = 0.01
d_vector=128

traj_maxlen = 1500
traj_minlen = 10

learning_rate = 0.1
batch_size = 32 #50
epochs = 200

processor = 25
per_process_size = 200

state_now = 'vali'  

dataset='AIS'
distance_type= 'dtw'


