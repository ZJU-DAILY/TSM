from torch.nn import Module, Parameter
import torch
import numpy as np
import pickle
import math
import config
import random
import torch.nn.functional as F
import traj_dist.distance as tdist
import time

class LossFun(Module):
    def __init__(self,batch_size,r_subsample,distance_type,dataset_type):
        super(LossFun, self).__init__()
        self.batch_size = batch_size
        self.r_subsample = r_subsample
        self.distance_type = distance_type

        self.triplet_subloss = pickle.load(open('./features/{}/{}_truth/{}_{}_subloss'.format(config.dataset, config.distance_type, config.dataset, config.distance_type), 'rb'))[:config.train_radio]
        self.triplet_tenRandom = pickle.load(open('./features/{}/{}_truth/{}_{}_tenRandom'.format(config.dataset, config.distance_type, config.dataset,config.distance_type), 'rb'))[:config.train_radio]

    def forward(self,input_a,input_p,input_n,embedding_a,embedding_p,embedding_n,batch_num):  # input:[20,len,2]  embedding: [20,len,128]
        batch_loss=0.0
        batch_num = batch_num*self.batch_size
        for i in range(self.batch_size):
            # print(batch_num)
            D_ap = self.triplet_subloss[batch_num][0][0]
            D_an = self.triplet_subloss[batch_num][0][1]
            v_ap = torch.exp(-torch.dist(embedding_a[i][-1], embedding_p[i][-1], p=2))
            v_an = torch.exp(-torch.dist(embedding_a[i][-1], embedding_n[i][-1], p=2))
            loss_entire_ap = D_ap * ((D_ap - v_ap) ** 2)
            loss_entire_an = D_an * ((D_an - v_an) ** 2)

            subloss = 0.0
            for j in range(config.r_subsample):
                sub_D_ap = self.triplet_subloss[batch_num][j+1][0]
                sub_D_an = self.triplet_subloss[batch_num][j+1][1]

                r1 = self.triplet_tenRandom[batch_num][j][0]
                r2 = self.triplet_tenRandom[batch_num][j][1]
                r3 = self.triplet_tenRandom[batch_num][j][2]

                # sub_D_ap = math.exp(-self.alpha * tdist.frechet(input_a[i][:r1], input_p[i][:r2]))
                # sub_D_an = math.exp(-self.alpha * tdist.frechet(input_a[i][:r1], input_n[i][:r3]))
                sub_v_ap = torch.exp(-torch.dist(embedding_a[i][r1 - 1], embedding_p[i][r2 - 1], p=2))
                sub_v_an = torch.exp(-torch.dist(embedding_a[i][r1 - 1], embedding_n[i][r3 - 1], p=2))
                subloss += sub_D_ap * ((sub_D_ap - sub_v_ap) ** 2) + sub_D_an * ((sub_D_an - sub_v_an) ** 2)
            subloss = subloss / config.r_subsample
            oneloss = subloss + loss_entire_ap + loss_entire_an
            batch_loss += oneloss
            batch_num += 1

        mean_batch_loss=batch_loss/self.batch_size
        sum_batch_loss=batch_loss

        return mean_batch_loss
