import config
import torch
import pickle
import numpy as np
import random
from lossfun import LossFun
from network import Main_Network
import test_method as tm
import time
import os

random.seed(1010)

def padding(trajs):
    traj_len = []
    maxlen = 0
    for t in trajs:
        traj_len.append(len(t))
        if len(t)>maxlen :
            maxlen = len(t)

    pad_seq = []
    for t in trajs:
        p = [0.0,0.0]
        t = t.tolist()
        while len(t)<maxlen:
            t.append(p)
        pad_seq.append(np.array(t))
    pad_seq = np.array(pad_seq)

    return pad_seq , traj_len


class T2SV_Trainer(object):
    def __init__(self,target_size,batch_size,learning_rate=config.learning_rate):
        self.target_size=target_size
        self.batch_size=batch_size
        self.learning_rate=learning_rate

    def T2SVeval(self,load_model=None):

        net = Main_Network(2, self.target_size, self.batch_size)
        net.cuda()
        
        with torch.no_grad():

            # test_set = pickle.load(open('./features/{}/{}_test_set_coor'.format(config.dataset, config.dataset),'rb'))[:6000]
            test_set = np.load('./data/{}/shuffle_coor_list_len0.6.npy'.format(config.dataset), allow_pickle=True)[4000:10000]
            if load_model!=None:
                net.load_state_dict(torch.load(load_model))
                embedding_test_set = tm.compute_embedding(self, net, test_set, 200)  # 对轨迹进行embedding
                acc = tm.test_model(self, test_set, embedding_test_set, isvali=False)

                print('test_eval: ', acc)


    def T2SVtrain(self,load_model=None,load_optimizer=None):

        net = Main_Network(2,self.target_size,self.batch_size)
        optimizer = torch.optim.Adam([p for p in net.parameters() if p.requires_grad], lr=config.learning_rate)
        lossfunction = LossFun(self.batch_size,config.r_subsample,config.distance_type,dataset_type=config.dataset)

        net.cuda()
        lossfunction.cuda()

        all_apn_triplets = pickle.load(open('./features/{}/{}_apn_triplets'.format(config.dataset,config.dataset), 'rb')) 
        all_apn_triplets = all_apn_triplets[:config.train_radio]
        print(len(all_apn_triplets))

        vali_set = pickle.load(open('./features/{}/{}_vali_set_coor'.format(config.dataset, config.dataset),'rb'))

        lastepoch = '0'
        if load_model != None:
            net.load_state_dict(torch.load(load_model))
            # optimizer.load_state_dict(torch.load(load_optimizer))
            lastepoch = load_model.split('/')[-1].split('_')[3] 
        start = time.time()
        for epoch in range(int(lastepoch),config.epochs):
            if epoch!=0 and epoch%10==0:
                end=time.time()
                print("10epoch training time:",end-start)
                start = time.time()

            net.train()

            input_a = []
            input_p = []
            input_n = []

            batch_num = 0
            for i,apn_triplet in enumerate(all_apn_triplets):
                input_a.append(apn_triplet[0])
                input_p.append(apn_triplet[1])
                input_n.append(apn_triplet[2])
                if len(input_a) == self.batch_size:
                    # s1 = time.time()
                    input_a_pad, input_a_len = padding(trajs=input_a)
                    input_p_pad, input_p_len = padding(trajs=input_p)
                    input_n_pad, input_n_len = padding(trajs=input_n)
                    # s2 = time.time()
                    embedding_a = net(input_a_pad, input_a_len) 
                    embedding_p = net(input_p_pad, input_p_len)
                    embedding_n = net(input_n_pad, input_n_len)
                    # s3 = time.time()
                    loss = lossfunction(input_a, input_p, input_n, embedding_a, embedding_p, embedding_n, batch_num)
                    batch_num+=1
                    # s4 = time.time()
                    optimizer.zero_grad()
                    loss.backward()
                    optimizer.step()
                    # s5 = time.time()
                    input_a = []
                    input_p = []
                    input_n = []
                    # print(s2-s1)
                    # print(s3-s2)
                    # print(s4-s3)
                    # print(s5-s4)
                    # print(s5-s1)
            
            net.eval()
            with torch.no_grad():
                embedding_vali_set = tm.compute_embedding(self,net,vali_set,100)  # 对轨迹进行embedding
                acc = tm.test_model(self,vali_set,embedding_vali_set,isvali=True) # 验证 计算HR10，HR50

                print(epoch,acc[1],loss.item()) #dlhu #acc[0]

                # save model
                save_modelname='./model/{}/{}_out_res/{}_{}_epoch_{}_HR10_{}_HR50_{}_Loss_{}.pkl'.format(config.dataset,config.distance_type , config.dataset,config.distance_type,str(epoch),acc[0],acc[1],loss.item())
                os.makedirs(os.path.dirname(save_modelname), exist_ok=True)
                torch.save(net.state_dict(),save_modelname)

                save_optname = './optimizer/{}/{}_out_res/{}_{}_epoch_{}.pkl'.format(config.dataset,config.distance_type , config.dataset, config.distance_type,str(epoch))
                os.makedirs(os.path.dirname(save_optname), exist_ok=True)
                torch.save(optimizer.state_dict(),save_optname)
