import torch
import torch.nn as nn
from torch.nn.parameter import Parameter
import torch.nn.functional as F
import config
import random
import numpy as np
import pickle
import pandas as pd
import math
import os

os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"

os.environ["CUDA_VISIBLE_DEVICES"] = config.GPU

class LSTMcell(nn.Module):
    def __init__(self, input_size, hidden_size):
        super(LSTMcell, self).__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size

        self.weight_ih = Parameter(torch.Tensor(4 * hidden_size, input_size)) 
        self.weight_hh = Parameter(torch.Tensor(4 * hidden_size, hidden_size))
        self.bias_ih = Parameter(torch.Tensor(4 * hidden_size))
        self.bias_hh = Parameter(torch.Tensor(4 * hidden_size))

        self.reset_parameters()

    def reset_parameters(self):
        stdv = 1.0 / math.sqrt(self.hidden_size)
        for weight in self.parameters():
            weight.data.uniform_(-stdv, stdv)

    def forward(self, input, hx):
        return self.lstm_cell(input, hx, self.weight_ih, self.weight_hh, self.bias_ih, self.bias_hh)

    def lstm_cell(self, input, hidden, w_ih, w_hh, b_ih=None, b_hh=None):
        hx, cx = hidden

        gates = F.linear(input, w_ih, b_ih) + F.linear(hx, w_hh, b_hh)
        ingate, forgetgate, cellgate, outgate = gates.chunk(4, 1)

        ingate = F.sigmoid(ingate)
        forgetgate = F.sigmoid(forgetgate)
        cellgate = F.tanh(cellgate)
        outgate = F.sigmoid(outgate)

        cy = (forgetgate * cx) + (ingate * cellgate) 
        hy = outgate * F.tanh(cy) 

        return hy, cy


class LSTMencoder(nn.Module):
    def __init__(self, input_size, hidden_size):
        super(LSTMencoder, self).__init__()
        self.cell = LSTMcell(input_size, hidden_size).cuda()
        self.hidden_size = hidden_size

        self.residual_wi = Parameter(torch.Tensor(hidden_size, hidden_size))
        self.residual_wc = Parameter(torch.Tensor(hidden_size, hidden_size))
        self.residual_wo = Parameter(torch.Tensor(hidden_size, hidden_size))
        self.residual_bi = Parameter(torch.Tensor(hidden_size))
        self.residual_bc = Parameter(torch.Tensor(hidden_size))
        self.residual_bo = Parameter(torch.Tensor(hidden_size))
        self.reset_parameters1()

    def reset_parameters1(self):
        stdv = 1.0 / math.sqrt(self.hidden_size)
        for weight in self.parameters():
            weight.data.uniform_(-stdv, stdv)

    def forward(self, input, batch_len,batch_size, init_state=None):
        out, state = init_state
        time_step = input.size(1) 
        outputs = []
        for t in range(time_step):
            cell_input = input[:, t, :]
            out, state = self.cell(cell_input, (out, state))

            rc = F.sigmoid(F.linear(out, self.residual_wi, self.residual_bi)) * F.tanh(
                F.linear(out, self.residual_wc, self.residual_bc))
            rh = F.sigmoid(F.linear(out, self.residual_wo, self.residual_bo)) * F.tanh(rc)
            v = out + rh

            outputs.append(v) # [pad,20,128]


        emb = torch.cat(outputs , dim = 0)  
        emb = emb.view(-1,batch_size,config.d_vector) 
        emb = torch.transpose(emb,0,1) 

        batch_emb = []
        for i,len in enumerate(batch_len):
            batch_emb.append(emb[i,:len,:])

        return batch_emb  

class Main_Network(nn.Module):
    def __init__(self, input_size, target_size, batch_size):
        super(Main_Network, self).__init__()
        self.input_size = input_size
        self.target_size = target_size
        self.batch_size = batch_size

        self.hidden = (
        torch.zeros(self.batch_size, self.target_size).cuda(), torch.zeros(self.batch_size, self.target_size).cuda())
        self.lstm = LSTMencoder(self.input_size, self.target_size).cuda()

    def forward(self, input_batch , batch_len):
        input = torch.Tensor(input_batch)  # [20,pad,2]
        embedding = self.lstm(input.cuda(),batch_len,self.batch_size, self.hidden) 
        return embedding
