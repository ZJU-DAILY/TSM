import torch
import config
import random
import numpy as np
import pickle
import pandas as pd
from sklearn.neighbors import KDTree
from sklearn.neighbors import BallTree
import math
import traj_dist.distance as tdist
import os
import time

# porto_lat_range = [40.953673,41.307945]
# porto_lon_range = [-8.735152,-8.156309]

# hangzhou_lat_range = [30.0,30.5]
# hangzhou_lon_range = [119.8,120.6]

# geolife_lat_range = [39.5,40.3]
# geolife_lon_range = [116.1,116.8]

# chengdu_lat_range = [30.64,30.73]
# chengdu_lon_range = [104.03,104.13]

ais_lon_range = [-159.90567, 10.37495]
ais_lat_range = [146.01674, 61.22504]

class Preprocesser(object):
    def __init__(self, delta = 0.005, lat_range = [1,2], lon_range = [1,2]):
        self.delta = delta
        self.lat_range = lat_range
        self.lon_range = lon_range
        self._init_grid_hash_function()

    def _init_grid_hash_function(self):
        dXMax, dXMin, dYMax, dYMin = self.lon_range[1], self.lon_range[0], self.lat_range[1], self.lat_range[0]
        x  = self._frange(dXMin,dXMax, self.delta) 
        y  = self._frange(dYMin,dYMax, self.delta) 
        self.x = x
        self.y = y

    def _frange(self, start, end=None, inc=None):
        "A range function, that does accept float increments..."
        if end == None:
            end = start + 0.0
            start = 0.0
        if inc == None:
            inc = 1.0
        L = []
        while 1:
            next = start + len(L) * inc
            if inc > 0 and next >= end:
                break
            elif inc < 0 and next <= end:
                break
            L.append(next)
        return L

    def get_grid_index(self, tuple): 
        test_tuple = tuple
        test_x,test_y = test_tuple[0],test_tuple[1]
        x_grid = int ((test_x-self.lon_range[0])/self.delta)
        y_grid = int ((test_y-self.lat_range[0])/self.delta)
        index = (y_grid)*(len(self.x)) + x_grid
        return x_grid,y_grid, index

    def traj2grid_seq(self, trajs = [], isCoordinate = False): 
        grid_traj = []
        for r in trajs:
            x_grid, y_grid, index = self.get_grid_index((r[0],r[1]))
            grid_traj.append(index)
        privious = None
        hash_traj = []
        for index, i in enumerate(grid_traj): 
            if privious==None:
                privious = i
                if isCoordinate == False:
                    hash_traj.append(i)
                elif isCoordinate == True:
                    hash_traj.append(trajs[index][0:])
            else:
                if i==privious:
                    pass
                else:
                    if isCoordinate == False:
                        hash_traj.append(i)
                    elif isCoordinate == True:
                        hash_traj.append(trajs[index][0:])
                    privious = i
        return hash_traj

def ksegment_traj(lat_range = ais_lat_range,lon_range = ais_lon_range):
    fname = config.dataset
    trajs = np.load('./data/{}/shuffle_coor_list.npy'.format(config.dataset), allow_pickle=True) 
    print("len(trajs):",len(trajs))
    preprocessor = Preprocesser(delta=0.0005, lat_range=lat_range, lon_range=lon_range)
    coor_trajs = []
    for i, traj in enumerate(trajs):
        new_traj = []

        for p in traj:
            new_traj.append([p[0], p[1]])

        coor_traj = preprocessor.traj2grid_seq(new_traj, isCoordinate=True)

        coor_trajs.append(coor_traj)

        if i % 5000 == 0:
            print("i:",i)

        if len(coor_trajs) == config.all_traj_number:
            break

    print("len(coor_trajs)",len(coor_trajs))
    filename = './features/{}/{}_traj_coor'.format(fname, fname)
    os.makedirs(os.path.dirname(filename), exist_ok=True)
    pickle.dump(coor_trajs, open('./features/{}/{}_traj_coor'.format(fname, fname), 'wb'))

    kseg_coor_trajs=[]
    for t in trajs: 
        kseg_coor=[]
        seg=len(t)//config.k_segment
        t=np.array(t)
        for i in range(config.k_segment):
            if i==config.k_segment-1:
                kseg_coor.append(np.mean(t[i*seg:],axis=0))
            else:
                kseg_coor.append(np.mean(t[i * seg:i*seg+seg], axis=0))
        kseg_coor_trajs.append(kseg_coor)
    filename = './features/{}/{}_traj_coor_kseg'.format(fname, fname)
    os.makedirs(os.path.dirname(filename), exist_ok=True)
    pickle.dump(kseg_coor_trajs,open('./features/{}/{}_traj_coor_kseg'.format(fname, fname),'wb'))
    print("kseg_coor_trajs[0]:",kseg_coor_trajs[0])

random.seed(2021)
def get_triplets(kseg_path='./features/porto_traj_coor_kseg',coor_path = './features/porto_traj_coor',k_segment=11):
    fname=config.dataset
    kseg_coor_trajs=pickle.load(open(kseg_path,'rb'))
    kseg_train_set = kseg_coor_trajs[:3000] 

    coor_trajs = pickle.load(open(coor_path,'rb'))

    train_set = coor_trajs[:3000]    
    train_t = []
    for i in range(len(train_set)):
        train_t.append(np.array(train_set[i]))
    train_set = np.array(train_t)

    vali_set = coor_trajs[3000:4000]
    vali_t = []
    for i in range(len(vali_set)):
        vali_t.append(np.array(vali_set[i]))
    vali_set = np.array(vali_t)

    test_set = coor_trajs[4000:10000] 
    test_t = []
    for i in range(len(test_set)):
        test_t.append(np.array(test_set[i]))
    test_set = np.array(test_t)
    
    filename1 = './features/{}/{}_train_set_coor'.format(fname, fname)
    os.makedirs(os.path.dirname(filename1), exist_ok=True)
    filename2 = './features/{}/{}_vali_set_coor'.format(fname, fname)
    os.makedirs(os.path.dirname(filename2), exist_ok=True)
    filename3 = './features/{}/{}_test_set_coor'.format(fname, fname)
    os.makedirs(os.path.dirname(filename3), exist_ok=True)
    pickle.dump(train_set, open('./features/{}/{}_train_set_coor'.format(fname, fname), 'wb'))
    pickle.dump(vali_set, open('./features/{}/{}_vali_set_coor'.format(fname, fname), 'wb'))
    pickle.dump(test_set, open('./features/{}/{}_test_set_coor'.format(fname, fname), 'wb'))

    sample_train2D = np.array(kseg_train_set).reshape(-1,10) 
    kd_tree = KDTree(sample_train2D)

    anchor_index = list(range(3000)) 
    random.shuffle(anchor_index)
    anchor_index = anchor_index[:3000] 

    anp_triplets=[]

    for i in anchor_index:
        dist,index=kd_tree.query([sample_train2D[i]],k_segment)  # k nearest neighbors
        index1=list(index[0][1:]) 
        p_index = random.sample(index1,10)

        for x in range(10):
            p_sample=train_set[p_index[x]]  # positive sample
            n_sample=random.sample(list(train_set),1)[0]  # negative sample
            a_sample=train_set[i]

            anp_sample=[]
            anp_sample.append(a_sample)
            anp_sample.append(p_sample)
            anp_sample.append(n_sample)
            anp_triplets.append(anp_sample)

    # random.shuffle(anp_triplets)
    filename = './features/{}/{}_apn_triplets'.format(fname,fname)
    os.makedirs(os.path.dirname(filename), exist_ok=True)
    pickle.dump(anp_triplets,open('./features/{}/{}_apn_triplets'.format(fname,fname),'wb'))
    print("len(anp_triplets):",len(anp_triplets))
    print("anp_triplets[0]:",anp_triplets[0])

def subtraj_ground_truth(path = None , distance_type = config.distance_type):
    maxdistance = 0
    alpha = 1
    all_apn_triplets = pickle.load(open(path, 'rb'))

    #  the mean plus three times the variance of training sample distances for DTW.
    if distance_type == 'dtw':
        tmp = []
        for apn_triplet in all_apn_triplets:
            ap = tdist.dtw(apn_triplet[0], apn_triplet[1])
            an = tdist.dtw(apn_triplet[0], apn_triplet[2])
            tmp.append(ap)
            tmp.append(an)
        tmp = np.array(tmp)
        alpha = 1 / (np.mean(tmp) + (np.var(tmp)*3))

    # The tunable parameter α is the reciprocal of the maximum distance of training sample distances for Frechet and Hausdorff distance
    elif distance_type == 'discret_frechet':
        for apn_triplet in all_apn_triplets:
            ap = tdist.discret_frechet(apn_triplet[0], apn_triplet[1])
            an = tdist.discret_frechet(apn_triplet[0], apn_triplet[2])
            if ap > maxdistance:
                maxdistance = ap
            if an > maxdistance:
                maxdistance = an
        alpha = 1 / maxdistance

    elif distance_type == 'hausdorff':
        for apn_triplet in all_apn_triplets:
            ap = tdist.hausdorff(apn_triplet[0], apn_triplet[1])
            an = tdist.hausdorff(apn_triplet[0], apn_triplet[2])
            if ap > maxdistance:
                maxdistance = ap
            if an > maxdistance:
                maxdistance = an
        alpha = 1 / maxdistance

    elif distance_type == 'lcss':
        for apn_triplet in all_apn_triplets:
            ap = tdist.lcss(apn_triplet[0], apn_triplet[1], eps=0.003)
            an = tdist.lcss(apn_triplet[0], apn_triplet[2], eps=0.003)
            if ap > maxdistance:
                maxdistance = ap
            if an > maxdistance:
                maxdistance = an
        alpha = 1 / maxdistance
    elif distance_type == 'erp':
        for apn_triplet in all_apn_triplets:
            ap = tdist.erp(apn_triplet[0], apn_triplet[1])
            an = tdist.erp(apn_triplet[0], apn_triplet[2])
            if ap > maxdistance:
                maxdistance = ap
            if an > maxdistance:
                maxdistance = an
        alpha = 1 / maxdistance
    elif distance_type == 'edr':
        for apn_triplet in all_apn_triplets:
            ap = tdist.edr(apn_triplet[0], apn_triplet[1], eps=0.003)
            an = tdist.edr(apn_triplet[0], apn_triplet[2], eps=0.003)
            if ap > maxdistance:
                maxdistance = ap
            if an > maxdistance:
                maxdistance = an
        alpha = 1 / maxdistance
    elif distance_type == 'sowd_grid':
        for apn_triplet in all_apn_triplets:
            ap = tdist.sowd_grid(apn_triplet[0], apn_triplet[1])
            an = tdist.sowd_grid(apn_triplet[0], apn_triplet[2])
            if ap > maxdistance:
                maxdistance = ap
            if an > maxdistance:
                maxdistance = an
        alpha = 1 / maxdistance



    all_sub_loss = []
    all_ten_random = []
    for triplet in all_apn_triplets:
        ten_sub = []
        ten_random = []
        if distance_type == 'discret_frechet':
            D_ap = math.exp(-alpha * tdist.discret_frechet(triplet[0], triplet[1]))
            D_an = math.exp(-alpha * tdist.discret_frechet(triplet[0], triplet[2]))
        elif distance_type == 'hausdorff':
            D_ap = math.exp(-alpha * tdist.hausdorff(triplet[0], triplet[1]))
            D_an = math.exp(-alpha * tdist.hausdorff(triplet[0], triplet[2]))
        elif distance_type == 'dtw':
            D_ap = math.exp(-alpha * tdist.dtw(triplet[0], triplet[1]))
            D_an = math.exp(-alpha * tdist.dtw(triplet[0], triplet[2]))
        elif distance_type == 'lcss':
            D_ap = math.exp(-alpha * tdist.lcss(triplet[0], triplet[1], eps=0.003))
            D_an = math.exp(-alpha * tdist.lcss(triplet[0], triplet[2], eps=0.003))
        elif distance_type == 'erp':
            D_ap = math.exp(-alpha * tdist.erp(triplet[0], triplet[1]))
            D_an = math.exp(-alpha * tdist.erp(triplet[0], triplet[2]))
        elif distance_type == 'edr':
            D_ap = math.exp(-alpha * tdist.edr(triplet[0], triplet[1], eps=0.003))
            D_an = math.exp(-alpha * tdist.edr(triplet[0], triplet[2], eps=0.003))
        elif distance_type == 'sowd_grid':
            D_ap = math.exp(-alpha * tdist.sowd_grid(triplet[0], triplet[1]))
            D_an = math.exp(-alpha * tdist.sowd_grid(triplet[0], triplet[2]))

        ten_sub.append([D_ap, D_an])
        for j in range(config.r_subsample):

            r1 = random.randint(1, len(triplet[0]))
            r2 = random.randint(1, len(triplet[1]))
            r3 = random.randint(1, len(triplet[2]))

            # print([r1,r2,r3])

            ten_random.append([r1,r2,r3])

            if distance_type == 'discret_frechet':
                sub_D_ap = math.exp(-alpha * tdist.discret_frechet(triplet[0][:r1], triplet[1][:r2]))
                sub_D_an = math.exp(-alpha * tdist.discret_frechet(triplet[0][:r1], triplet[2][:r3]))
            elif distance_type == 'hausdorff':
                sub_D_ap = math.exp(-alpha * tdist.hausdorff(triplet[0][:r1], triplet[1][:r2]))
                sub_D_an = math.exp(-alpha * tdist.hausdorff(triplet[0][:r1], triplet[2][:r3]))
            elif distance_type == 'dtw':
                sub_D_ap = math.exp(-alpha * tdist.dtw(triplet[0][:r1], triplet[1][:r2]))
                sub_D_an = math.exp(-alpha * tdist.dtw(triplet[0][:r1], triplet[2][:r3]))
            
            elif distance_type == 'lcss':
                sub_D_ap = math.exp(-alpha * tdist.lcss(triplet[0][:r1], triplet[1][:r2], eps=0.003))
                sub_D_an = math.exp(-alpha * tdist.lcss(triplet[0][:r1], triplet[2][:r3], eps=0.003))
            elif distance_type == 'erp':
                sub_D_ap = math.exp(-alpha * tdist.erp(triplet[0][:r1], triplet[1][:r2]))
                sub_D_an = math.exp(-alpha * tdist.erp(triplet[0][:r1], triplet[2][:r3]))
            elif distance_type == 'edr':
                sub_D_ap = math.exp(-alpha * tdist.edr(triplet[0][:r1], triplet[1][:r2], eps=0.003))
                sub_D_an = math.exp(-alpha * tdist.edr(triplet[0][:r1], triplet[2][:r3], eps=0.003))
            elif distance_type == 'sowd_grid':
                sub_D_ap = math.exp(-alpha * tdist.sowd_grid(triplet[0][:r1], triplet[1][:r2]))
                sub_D_an = math.exp(-alpha * tdist.sowd_grid(triplet[0][:r1], triplet[2][:r3]))

            ten_sub.append([sub_D_ap,sub_D_an])

        all_sub_loss.append(ten_sub)
        all_ten_random.append(ten_random)

    filename1 = './features/{}/{}_truth/{}_{}_subloss'.format(config.dataset, config.distance_type, config.dataset, config.distance_type)
    os.makedirs(os.path.dirname(filename1), exist_ok=True)
    filename2 = './features/{}/{}_truth/{}_{}_tenRandom'.format(config.dataset, config.distance_type, config.dataset,config.distance_type)
    os.makedirs(os.path.dirname(filename2), exist_ok=True)
    pickle.dump(all_sub_loss, open('./features/{}/{}_truth/{}_{}_subloss'.format(config.dataset, config.distance_type, config.dataset, config.distance_type), 'wb'))
    pickle.dump(all_ten_random, open('./features/{}/{}_truth/{}_{}_tenRandom'.format(config.dataset, config.distance_type, config.dataset,config.distance_type), 'wb'))

if __name__ == '__main__':
    start=time.time()
    ksegment_traj()

    get_triplets(kseg_path='./features/{}/{}_traj_coor_kseg'.format(config.dataset, config.dataset),
                 coor_path ='./features/{}/{}_traj_coor'.format(config.dataset,config.dataset),
                 k_segment= 11)
    
    subtraj_ground_truth(path='./features/{}/{}_apn_triplets'.format(config.dataset,config.dataset))
    end = time.time()
    print("preprocessing time:",end- start)















