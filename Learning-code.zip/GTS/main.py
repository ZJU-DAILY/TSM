from Trainer import STsim_Trainer
import torch
import os
import time

if __name__ == '__main__':
    print(torch.__version__)
    print(torch.cuda.device_count())
    print(torch.cuda.is_available())
    #torch.cuda.empty_cache()

    # train and test
    start = time.time()
    STsim = STsim_Trainer()

    load_model_name = None
    
    load_optimizer_name = None 

    STsim.ST_train(load_model = load_model_name,load_optimizer= load_optimizer_name) for training
    #STsim.ST_eval(load_model=load_model_name) #for testing

    end = time.time()
    print("training time:",end-start)
    #print("testing time:",end-start)

