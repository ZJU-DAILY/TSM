## GTS

## Requirements
- Ubuntu OS
- Python >= 3.5 (Anaconda3 is recommended)
- PyTorch 1.4+
- A Nvidia GPU with cuda 10.2+

## Data
* Trajectory dataset (TDrive) is an open source data set

## Train

1. Data preprocessing (node embedding)

   ```shell
   python preprocess.py
   ```

2. Ground truth generating (It will take a while)

   ```shell
   python spatial_similarity.py
   ```

3. Triplets generating

   ```shell
   python data_utils.py
   ```

4. Training

   ```shell
   python main.py
   ```
